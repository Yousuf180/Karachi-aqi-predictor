import requests
import pandas as pd
from datetime import datetime

class AQIPipeline:
    def __init__(self, city="Karachi", api_key=None):
        self.city = city
        self.api_key = api_key

    def fetch_aqi(self):
        try:
            url = f"https://api.waqi.info/feed/{self.city}/?token={self.api_key}"
            response = requests.get(url).json()
            if response["status"] == "ok":
                return {"aqi": response["data"]["aqi"], "timestamp": datetime.now()}
            return None
        except Exception as e:
            print(f"Error: {e}")
            return None

    def run(self):
        data = self.fetch_aqi()
        if data:
            print(f"AQI for {self.city}: {data["aqi"]}")
        return data

if __name__ == "__main__":
    pipeline = AQIPipeline(api_key="YOUR_API_KEY")
    pipeline.run()
