import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
import joblib

class AQIModel:
    def __init__(self):
        self.model = None

    def train(self):
        data = []
        for hour in range(24*30):
            aqi = 85 + 30 * np.sin(2 * np.pi * (hour % 24 - 8) / 24) + np.random.normal(0, 10)
            data.append({"hour": hour % 24, "aqi": max(0, aqi)})

        df = pd.DataFrame(data)
        X_train, X_test, y_train, y_test = train_test_split(df[["hour"]], df["aqi"], test_size=0.2)

        self.model = RandomForestRegressor(n_estimators=100, random_state=42)
        self.model.fit(X_train, y_train)

        score = r2_score(y_test, self.model.predict(X_test))
        print(f"Model R² Score: {score:.3f}")
        return score

    def save(self, path="models/aqi_model.pkl"):
        joblib.dump(self.model, path)
        print(f"Model saved to {path}")

if __name__ == "__main__":
    model = AQIModel()
    model.train()
    model.save()
