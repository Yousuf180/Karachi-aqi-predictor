import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from datetime import datetime
import random

st.set_page_config(page_title="Karachi AQI Predictor", page_icon="🇵🇰", layout="wide")

st.title("🇵🇰 Karachi Air Quality Predictor")
st.markdown("### Real-time AQI Monitoring & Forecasting System")

with st.sidebar:
    st.header("📍 Karachi, Pakistan")
    st.markdown(f"**Date:** {datetime.now().strftime('%B %d, %Y')}")
    st.markdown("---")
    st.markdown("### AQI Categories")
    st.markdown("- 🟢 0-50: Good")
    st.markdown("- 🟡 51-100: Moderate")
    st.markdown("- 🟠 101-150: Unhealthy")
    st.markdown("- 🔴 151-200: Unhealthy")
    st.markdown("- ⚫ 201-500: Hazardous")

current_aqi = random.randint(60, 150)

col1, col2, col3, col4 = st.columns(4)
with col1:
    st.metric("Current AQI", current_aqi)
with col2:
    st.metric("PM2.5", f"{current_aqi * 0.6:.1f}")
with col3:
    st.metric("PM10", f"{current_aqi * 0.8:.1f}")
with col4:
    st.metric("Temperature", f"{random.randint(25, 38)}°C")

st.subheader("7-Day Forecast")
forecast_data = []
for i in range(7):
    forecast_aqi = current_aqi + random.randint(-30, 40)
    forecast_data.append({"Day": f"Day {i+1}", "AQI": max(30, min(300, forecast_aqi))})
st.dataframe(pd.DataFrame(forecast_data), use_container_width=True)

st.subheader("72-Hour Trend")
hours = list(range(0, 73, 6))
values = [current_aqi + random.randint(-20, 30) for _ in hours]
fig = go.Figure()
fig.add_trace(go.Scatter(x=hours, y=values, mode='lines+markers'))
fig.add_hline(y=50, line_dash="dash", line_color="green")
fig.add_hline(y=100, line_dash="dash", line_color="yellow")
fig.update_layout(height=400)
st.plotly_chart(fig, use_container_width=True)

if current_aqi > 150:
    st.error("High AQI - Wear masks, stay indoors")
elif current_aqi > 100:
    st.warning("Moderate AQI - Limit outdoor activities")
else:
    st.success("Good AQI - Safe for outdoor activities")

st.markdown(f"---\n<center>Built for Karachi | {datetime.now().strftime('%Y-%m-%d')}</center>", unsafe_allow_html=True)
