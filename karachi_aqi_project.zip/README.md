# Karachi Air Quality Predictor

## Features
- Real-time AQI monitoring
- 7-day forecasts
- Health recommendations

## Installation
```bash
pip install -r requirements.txt
streamlit run dashboard/app.py
```

## AQI Categories
- 0-50: Good
- 51-100: Moderate
- 101-150: Unhealthy
- 151-200: Unhealthy
- 201-500: Hazardous

Made with ❤️ for Karachi